Globals:
- LE_VERSION (return version of the Live Editor as string)_